import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.DriverManager;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JFrame;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import java.awt.FlowLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.ListSelectionEvent;
import java.sql.ResultSet;

public class DBProject {
	
	private static String jdbcURL = "jdbc:hsqldb:hsql://localhost/testdb";
    private static String jdbcUsername = "SA";
    private static String jdbcPassword = "";

    private static final String dropTableSQL = "DROP TABLE IF EXISTS person;";
    private static final String createTableSQL = "CREATE TABLE person (id INT,firstName VARCHAR(20),lastName VARCHAR(30),PRIMARY KEY (id));";
		
    private static final String dropAddressTableSQL = "DROP TABLE IF EXISTS address;";
    private static final String createAddressTableSQL = "CREATE TABLE address (id INT primary key,street VARCHAR(20),city VARCHAR(30),state VARCHAR(20),postcode VARCHAR(40));";

    private static JTextField idField,firstField,lastField,streetField,cityField,stateField,postField;
	private static JComboBox addIDField;
	private static JLabel errorLabel,countLabel,errorAddress;
	private static JTable table,addressTable;
	private static JButton deleteButton,deleteAddress;
	private static final Object[] columnNames = {"ID","First Name","Last Name"};
	private static final Object[] addressColumns = {"ID","Street","City","State","Postcode"};

    public static void main(String[] argv) throws SQLException {
        DBProject dbProject = new DBProject();
        dbProject.createTable();
		dbProject.createUI();
    }
	
	public static Connection getConnection() {
        Connection connection = null;
        try {
            connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return connection;
    }

    public static void printSQLException(SQLException ex) {
        for (Throwable e: ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
	
	private static void addPerson(String id,String first,String last) {
		String addPersonString = "INSERT INTO person VALUES ("+id+",'"+first+"','"+last+"'); ";
		
        try (Connection connection = getConnection();
            Statement statement = connection.createStatement();) {

            statement.execute(addPersonString);
        } catch (SQLException e) {
            printSQLException(e);
        } finally {
			countLabel.setText("Current count of Persons:"+getPersonCount());
			populateTable(table);
			addIDField.addItem(id);
		}
	}
	
	private static void addAddress(String id,String street,String city,String state,String postcode) {
		String addAddressString = "INSERT INTO address VALUES ("+id+",'"+street+"','"+city+"','"+state+"','"+postcode+"');";
		
        try (Connection connection = getConnection();
            Statement statement = connection.createStatement();) {

            statement.execute(addAddressString);
        } catch (SQLException e) {
            printSQLException(e);
        } finally {
			populateAddressTable(table);
		}
	}
	
	private static void updatePerson(String id,String first,String last) {
		String editPersonString = "UPDATE person SET firstName = '"+first+"', lastName='"+last+"' WHERE id = "+id+";";
		
        try (Connection connection = getConnection();
            Statement statement = connection.createStatement();) {
		    statement.execute(editPersonString);
        } catch (SQLException e) {
            printSQLException(e);
        } finally {
			populateTable(table);
		}
	}
	
	private static void updateAddress(String id,String street,String city,String state,String postcode) {
		String editAddressString = "UPDATE address SET street = '"+street+"', city='"+city+"',state='"+state+
		"',postcode='"+postcode+"' WHERE id = "+id+";";
		
        try (Connection connection = getConnection();
            Statement statement = connection.createStatement();) {
		    statement.execute(editAddressString);
        } catch (SQLException e) {
            printSQLException(e);
        } finally {
			populateAddressTable(table);
		}
	}
	
	private static void deletePerson(String id, int index) {
		String deletePersonString = "DELETE FROM person WHERE id = "+id+";";
		
		deleteAddress(id);
        try (Connection connection = getConnection();
            Statement statement = connection.createStatement();) {

            statement.execute(deletePersonString);
        } catch (SQLException e) {
            printSQLException(e);
        } finally {
			countLabel.setText("Current count of Persons:"+getPersonCount());
			populateTable(table);
			deleteButton.setEnabled(false);
			System.out.println("rem = "+index);
			addIDField.removeItemAt(index);
		}
	}
	
	private static void deleteAddress(String id) {
		String deleteAddressString = "DELETE FROM address WHERE id = "+id+";";
		
        try (Connection connection = getConnection();
            Statement statement = connection.createStatement();) {

            statement.execute(deleteAddressString);
        } catch (SQLException e) {
            printSQLException(e);
        } finally {
			populateAddressTable(table);
			deleteAddress.setEnabled(false);
		}
	}
	
	private static int getPersonCount() {
	    int count = 0;
		String countString = "SELECT COUNT(*) AS total FROM person;";
		try (Connection connection = getConnection();
            Statement statement = connection.createStatement();) {

            ResultSet rs = statement.executeQuery(countString);
	        while(rs.next()){
                count = rs.getInt("total");
            }
			rs.close();
        } catch (SQLException e) {
            printSQLException(e);
        }
		return count;
	}
	
	private static int getAddressCount() {
	    int count = 0;
		String countString = "SELECT COUNT(*) AS total FROM address;";
		try (Connection connection = getConnection();
            Statement statement = connection.createStatement();) {

            ResultSet rs = statement.executeQuery(countString);
	        while(rs.next()){
                count = rs.getInt("total");
            }
			rs.close();
        } catch (SQLException e) {
            printSQLException(e);
        }
		return count;
	}
	
	private static int getPersonCountForID(String id) {
	    int count = 0;
		String countString = "SELECT COUNT(*) AS total FROM person WHERE id = "+id+";";
		try (Connection connection = getConnection();
            Statement statement = connection.createStatement();) {

            ResultSet rs = statement.executeQuery(countString);
	        while(rs.next()){
                count = rs.getInt("total");
            }
			rs.close();
        } catch (SQLException e) {
            printSQLException(e);
        }
		return count;
	}
	
	private static int getAddressCountForID(String id) {
	    int count = 0;
		String countString = "SELECT COUNT(*) AS total FROM address WHERE id = "+id+";";
		try (Connection connection = getConnection();
            Statement statement = connection.createStatement();) {

            ResultSet rs = statement.executeQuery(countString);
	        while(rs.next()){
                count = rs.getInt("total");
            }
			rs.close();
        } catch (SQLException e) {
            printSQLException(e);
        }
		return count;
	}
	
	private static String checkAddState(String id, String first, String last) {
		if(id.length() == 0 || !isNumeric(id)) {
			return "Please enter a valid number in the ID field";
		}
		
		int addCount = getPersonCountForID(id);
		if(addCount > 0) {
			return "A person with id '"+id+"' already exists. Enter a unique id";
		}
		
		if(first.trim().length() == 0) {
			return "Please enter a non empty value into First Name field";
		}
		
		if(last.trim().length() == 0) {
			return "Please enter a non empty value into Last Name field";
		}
		
		return "";
	}
	
	private static String checkAddressState(String id,String street,String city,String state,String postcode) {
		if(id.length() == 0 || !isNumeric(id)) {
			return "Please select a valid number in the ID field for an address";
		}
		
		int addCount = getAddressCountForID(id);
		if(addCount > 0) {
			return "Only 1 address allowed at a time for id '"+id+"'";
		}
		
		if(street.trim().length() == 0) {
			return "Please enter a non empty value into Street field";
		} else if(city.trim().length() == 0) {
			return "Please enter a non empty value into City field";
		} else if(state.trim().length() == 0) {
			return "Please enter a non empty value into State field";
		} else if(postcode.trim().length() == 0) {
			return "Please enter a non empty value into Postcode field";
		}
		
		return "";
	}
	
	private static boolean isNumeric(String strNum) {
    if (strNum == null) {
        return false;
    }
    try {
        double d = Double.parseDouble(strNum);
    } catch (NumberFormatException nfe) {
        return false;
    }
    return true;
}
	
	public void createUI () {
	   JFrame frame = new JFrame("Person DB");
       frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       frame.setSize(800,650);
	   JPanel topPanel = new JPanel();
	   JPanel addPanel = new JPanel();
	   addPanel.setLayout(new FlowLayout(FlowLayout.LEADING));
	   
	   JLabel idLabel = new JLabel("ID:");
	   idField = new JTextField("");
	   idField.setColumns(4);
	   JLabel firstLabel = new JLabel("First Name:");
	   firstField = new JTextField("");
	   firstField.setColumns(12);
	   JLabel lastLabel = new JLabel("Last Name:");
	   lastField = new JTextField("");
	   lastField.setColumns(20);
       JButton button = new JButton("Add User");
	   button.addActionListener(new ActionListener(){  
		  public void actionPerformed(ActionEvent e){
            String id = idField.getText();
		    String first = firstField.getText();
		    String last = lastField.getText();			  
			String check = checkAddState(id,first,last);
			errorLabel.setText(check);
			if(check.length() == 0) {
				addPerson(id,first,last);
				idField.setText("");
		        firstField.setText("");
		        lastField.setText("");	
			}
		  }  
		});  
	   
	   addPanel.add(idLabel);
	   addPanel.add(idField);
	   addPanel.add(firstLabel);
	   addPanel.add(firstField);
	   addPanel.add(lastLabel);
	   addPanel.add(lastField);
	   addPanel.add(button);
	   
	   JPanel errorPanel = new JPanel();
	   errorLabel = new JLabel("");
	   errorPanel.add(errorLabel);
	   
	   topPanel.add(addPanel);
	   topPanel.add(errorPanel);
	   topPanel.add(createPersonTable());
	   topPanel.add(createAddressPanel());
	   topPanel.add(createAddressTable());
	   
	   frame.getContentPane().add(topPanel); 

       frame.setVisible(true);
	} 
	
	private JPanel createAddressPanel() {
	   JPanel topAddressPanel = new JPanel();
	   JPanel addressPanel = new JPanel();
	   addressPanel.setLayout(new GridLayout(2,3)); 
	   
	   JLabel idLabel = new JLabel("ID:");
	   addIDField = new JComboBox();
	   addIDField.setPreferredSize(new Dimension(45,20));
	   JLabel streetLabel = new JLabel("Street:");
	   streetField = new JTextField("");
	   streetField.setColumns(14);
	   JLabel cityLabel = new JLabel("City:");
	   cityField = new JTextField("");
	   cityField.setColumns(14);
	   JLabel stateLabel = new JLabel("State:");
	   stateField = new JTextField("");
	   stateField.setColumns(14);
	   JLabel postLabel = new JLabel("Postcode:");
	   postField = new JTextField("");
	   postField.setColumns(14);
	   
       JButton button = new JButton("Add Address");
	   button.addActionListener(new ActionListener(){  
		  public void actionPerformed(ActionEvent e){
            String id = (addIDField.getSelectedIndex() > -1) ? 
			addIDField.getItemAt(addIDField.getSelectedIndex()).toString() : "";
		    String street = streetField.getText();
		    String city = cityField.getText();		
			String state = stateField.getText();	
			String post = postField.getText();				
			String check = checkAddressState(id,street,city,state,post);
			errorAddress.setText(check);
			if(check.length() == 0) {
				addAddress(id,street,city,state,post);
		        cityField.setText("");
		        streetField.setText("");
				stateField.setText("");
		        postField.setText("");				
			}
		  }  
		});  
	   
	   
	   JPanel idPanel = new JPanel();
	   idPanel.add(idLabel);
	   idPanel.add(addIDField);
	   addressPanel.add(idPanel);
	   
	   JPanel streetPanel = new JPanel();
	   streetPanel.add(streetLabel);
	   streetPanel.add(streetField);
	   addressPanel.add(streetPanel);
	   
	   JPanel cityPanel = new JPanel();
	   cityPanel.add(cityLabel);
	   cityPanel.add(cityField);
	   addressPanel.add(cityPanel);
	   
	   JPanel statePanel = new JPanel();
	   statePanel.add(stateLabel);
	   statePanel.add(stateField);
	   addressPanel.add(statePanel);
	   
	   JPanel postPanel = new JPanel();
	   postPanel.add(postLabel);
	   postPanel.add(postField);
	   addressPanel.add(postPanel);
	   addressPanel.add(button);
	   
	   topAddressPanel.add(addressPanel);
	   
	   return topAddressPanel;
	}
	
	public static JPanel createPersonTable() {
	   JPanel personPanel = new JPanel();
	   personPanel.setLayout(new GridBagLayout()); 
	   GridBagConstraints c = new GridBagConstraints();
	   countLabel = new JLabel("Current count of Persons:0");
	   c.weightx = 1.0;
       c.fill = GridBagConstraints.HORIZONTAL;
       c.gridx = 0;
       c.gridy = 0;
	   personPanel.add(countLabel,c);
	   
	   deleteButton = new JButton("Delete Person");
	   c.weightx = 0.05;
       c.fill = GridBagConstraints.HORIZONTAL;
       c.gridx = 1;
       c.gridy = 0;
	   deleteButton.setEnabled(false);
	   deleteButton.addActionListener(new ActionListener(){  
		  public void actionPerformed(ActionEvent e){
			  try {			  
				int selectedRow = table.getSelectedRow();
				String id = table.getModel().getValueAt(selectedRow,0).toString();
				deletePerson(id,table.getSelectedRow());
			  }catch(Exception e2) {
				  e2.printStackTrace();
			  }
		  }  
		});  
	   personPanel.add(deleteButton,c);
	   
	   String data[][]={};    
	   table = new JTable();
	   table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	   table.setModel(new DefaultTableModel(columnNames, 0));
	   ListSelectionModel selectionModel = table.getSelectionModel();
	   selectionModel.addListSelectionListener(new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent e) {
				deleteButton.setEnabled(true);
			}
	   });

	   JScrollPane scrollPane = new JScrollPane(table);
	   scrollPane.setPreferredSize(new Dimension(700, 200));
	   table.setPreferredScrollableViewportSize(new Dimension(700, 200));
       table.setFillsViewportHeight(false);
       c.fill = GridBagConstraints.HORIZONTAL;
	   c.gridwidth = 5;
       c.gridx = 0;
       c.gridy = 1;
	   personPanel.add(scrollPane,c);
	   
	   return personPanel;
	}
	
	public static JPanel createAddressTable() {
	   JPanel addressPanel = new JPanel();
	   addressPanel.setLayout(new GridBagLayout()); 
	   GridBagConstraints c = new GridBagConstraints();
	   
	   errorAddress = new JLabel("");
       c.weightx = 1.0;
       c.fill = GridBagConstraints.HORIZONTAL;
       c.gridx = 0;
       c.gridy = 0;
	   addressPanel.add(errorAddress,c);
	   
	   deleteAddress = new JButton("Delete Address");
	   c.weightx = 0.05;
       c.fill = GridBagConstraints.HORIZONTAL;
       c.gridx = 1;
       c.gridy = 0;
	   deleteAddress.setEnabled(false);
	   deleteAddress.addActionListener(new ActionListener(){  
		  public void actionPerformed(ActionEvent e){
			  try {			  
				int selectedRow = addressTable.getSelectedRow();
				String id = addressTable.getModel().getValueAt(selectedRow,0).toString();
				deleteAddress(id);
			  }catch(Exception e2) {
				  e2.printStackTrace();
			  }
		  }  
		});  
	   addressPanel.add(deleteAddress,c);
	   
	   String data[][]={};    
	   addressTable = new JTable();
	   addressTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	   addressTable.setModel(new DefaultTableModel(addressColumns, 0));
	   ListSelectionModel selectionModel = addressTable.getSelectionModel();
	   selectionModel.addListSelectionListener(new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent e) {
				deleteAddress.setEnabled(true);
			}
	   });

	   JScrollPane scrollPane = new JScrollPane(addressTable);
	   scrollPane.setPreferredSize(new Dimension(700, 200));
	   addressTable.setPreferredScrollableViewportSize(new Dimension(700, 200));
       addressTable.setFillsViewportHeight(false);
       c.fill = GridBagConstraints.HORIZONTAL;
	   c.gridwidth = 5;
       c.gridx = 0;
       c.gridy = 2;
	   addressPanel.add(scrollPane,c);
	   
	   return addressPanel;
	}

    public void createTable() throws SQLException {
	    try (Connection connection = getConnection();

            Statement statement = connection.createStatement();) {
            statement.execute(dropTableSQL);
        } catch (SQLException e) {
            printSQLException(e);
        }
		
		try (Connection connection = getConnection();

            Statement statement = connection.createStatement();) {
            statement.execute(dropAddressTableSQL);
        } catch (SQLException e) {
            printSQLException(e);
        }
		
		try (Connection connection = getConnection();
            Statement statement = connection.createStatement();) {

            statement.execute(createTableSQL);
        } catch (SQLException e) {
            printSQLException(e);
        }
		
        try (Connection connection = getConnection();
            Statement statement = connection.createStatement();) {

            statement.execute(createAddressTableSQL);
        } catch (SQLException e) {
            printSQLException(e);
        }
    }
	
	public static void populateTable(JTable table){
		try
		{
			DefaultTableModel model = new DefaultTableModel(columnNames, 0) {
			    public boolean isCellEditable(int row,int column) {
				    return (column >= 1);
			    }
				
				public void setValueAt(Object obj, int row, int column) {
					int selectedRow = table.getSelectedRow();
				    String id = table.getModel().getValueAt(selectedRow,0).toString();	
					String value1 = "";
					String value2 = "";
					if(column == 1) {
						value1 = obj.toString();
						value2 = table.getModel().getValueAt(selectedRow,2).toString();	
					} else {
						value1 = table.getModel().getValueAt(selectedRow,1).toString();	
						value2 = obj.toString();
					}
					updatePerson(id,value1,value2);
				}
			};
			String queryString = "SELECT id,firstName,lastName FROM person;";
			Connection connection = getConnection();
			Statement statement = connection.createStatement();
			ResultSet rs = statement.executeQuery(queryString);
				
			int columns = rs.getMetaData().getColumnCount();
			int rowCount = getPersonCount();
			Object data[][]=new Object[rowCount][columns];
            int j = 0;			
			while(rs.next()) {  
				Object[] row = new Object[columns];
				for (int i = 1; i <= columns; i++) {  
					row[i - 1] = rs.getObject(i).toString();
				}
				model.addRow(row);
			}
			table.setModel(model);
			rs.close();
			statement.close();
			connection.close();		
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
	}
	
	public static void populateAddressTable(JTable table){
		try
		{
			DefaultTableModel model = new DefaultTableModel(addressColumns, 0) {
			    public boolean isCellEditable(int row,int column) {
				    return (column >= 1);
			    }
				
				public void setValueAt(Object obj, int row, int column) {
					int selectedRow = addressTable.getSelectedRow();
				    String id = addressTable.getModel().getValueAt(selectedRow,0).toString();	
					String value1 = addressTable.getModel().getValueAt(selectedRow,1).toString();
					String value2 = addressTable.getModel().getValueAt(selectedRow,2).toString();
					String value3 = addressTable.getModel().getValueAt(selectedRow,3).toString();
					String value4 = addressTable.getModel().getValueAt(selectedRow,4).toString();
					if(column == 1) {
						value1 = obj.toString();
					} else if(column == 2){
						value2 = obj.toString();
					} else if(column == 3){
						value3 = obj.toString();
					} else if(column == 4){
						value4 = obj.toString();
					}
					updateAddress(id,value1,value2,value3,value4);
				}
			};
			String queryString = "SELECT id,street,city,state,postcode FROM address;";
			Connection connection = getConnection();
			Statement statement = connection.createStatement();
			ResultSet rs = statement.executeQuery(queryString);
				
			int columns = rs.getMetaData().getColumnCount();
			int rowCount = getAddressCount();
			Object data[][]=new Object[rowCount][columns];
            int j = 0;			
			while(rs.next()) {  
				Object[] row = new Object[columns];
				for (int i = 1; i <= columns; i++) {  
					row[i - 1] = rs.getObject(i).toString();
				}
				model.addRow(row);
			}
			addressTable.setModel(model);
			rs.close();
			statement.close();
			connection.close();		
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
	}
}